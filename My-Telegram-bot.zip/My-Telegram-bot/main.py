
# ============================================
# 🤖 Telegram Gaming Group Bot by Vaibhav
# ============================================

import logging
import os
import time
import json
import asyncio
from datetime import datetime
from collections import defaultdict
from aiohttp import web
from telegram import Update, ChatPermissions, InputFile
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
)

# =====================
# 🔐 Bot Token
# =====================
BOT_TOKEN = os.getenv("BOT_TOKEN")  # ya directly paste karo: "123456:ABCDEF..."

# =====================
# ⚙️ Configurations
# =====================
FLOOD_LIMIT = 5
FLOOD_TIME = 6
MUTE_DURATION = 600
WARN_LIMIT = 3

# =====================
# 📁 File Paths
# =====================
DATA_FILE = "data.json"
GAMES_FILE = "games.json"
CATEGORIES_FILE = "categories.json"
REQUESTS_FILE = "requests.json"
CHANNEL_ID = -1002081570293  # backup channel ID

# =====================
# 📋 Logging Setup
# =====================
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =====================
# 🔃 Load Data
# =====================
def load_json(path, default): return json.load(open(path, 'r')) if os.path.exists(path) else default
data = load_json(DATA_FILE, {"xp": {}, "warns": {}})
game_posts = load_json(GAMES_FILE, {})
categories = load_json(CATEGORIES_FILE, {})
game_requests = load_json(REQUESTS_FILE, {})

user_xp = defaultdict(int, {int(k): v for k, v in data["xp"].items()})
user_warnings = defaultdict(int, {int(k): v for k, v in data["warns"].items()})
user_messages = defaultdict(list)

# =====================
# ❗ Constants
# =====================
BAD_WORDS = ["fuck", "bitch", "chutiya", "madarchod", "randi"]
CUSTOM_REPLIES = {
    "link": "🔗 Game links are only for channel followers. Check pinned post!",
    "offline": "📴 Server down ho sakta hai. Thoda ruk jao baby...",
    "error": "⚠️ Oops! Kuch galat ho gaya. Contact admin please!"
}
WELCOME_MESSAGE = "👋 Welcome to *The Gaming Vault*! Type /rules to know the rules baby!"
RULES_MESSAGE = "📜 *Group Rules*\n1. No spamming\n2. No bad words\n3. Respect all\n4. Use /find to search\n5. /requestgame to request"

# =====================
# 💾 Save Functions
# =====================
def save_data(): json.dump({"xp": dict(user_xp), "warns": dict(user_warnings)}, open(DATA_FILE, 'w'))
def save_games(): json.dump(game_posts, open(GAMES_FILE, 'w'))
def save_categories(): json.dump(categories, open(CATEGORIES_FILE, 'w'))
def save_requests(): json.dump(game_requests, open(REQUESTS_FILE, 'w'))

# =====================
# ✅ Command Handlers
# =====================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🤖 Bot is online & sexy as ever!\nUse /rules, /rank, /daily XP & more!")

async def rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text(RULES_MESSAGE, parse_mode="Markdown")
    try: await context.bot.pin_chat_message(update.effective_chat.id, msg.message_id)
    except Exception as e: logger.warning(f"Pin failed: {e}")

async def new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for member in update.message.new_chat_members:
        await update.message.reply_text(WELCOME_MESSAGE, parse_mode="Markdown")

async def rank(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.from_user.id
    xp = user_xp[uid]
    await update.message.reply_text(f"🏅 XP: {xp} | Level: {xp // 10}")

async def top(update: Update, context: ContextTypes.DEFAULT_TYPE):
    top_users = sorted(user_xp.items(), key=lambda x: x[1], reverse=True)[:5]
    leaderboard = "🏆 *Top 5 Members:*\n" + '\n'.join(f"{i+1}. User {uid} – {xp} XP" for i, (uid, xp) in enumerate(top_users))
    await update.message.reply_text(leaderboard, parse_mode="Markdown")

async def daily(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.from_user.id
    user_xp[uid] += 10
    save_data()
    await update.message.reply_text("🎁 Daily XP collected! +10 XP 🥳")

async def find(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = ' '.join(context.args).lower()
    if not query:
        await update.message.reply_text("❓ Use: /find <game name>")
        return
    matches = [g for g in game_posts if query in g.lower()]
    await update.message.reply_text("🎮 Found:\n" + '\n'.join(f"• {m}" for m in matches) if matches else "❌ No games found baby 😢")

async def suggest(update: Update, context: ContextTypes.DEFAULT_TYPE):
    genre = ' '.join(context.args).lower()
    genre_map = {
        "action": ["GTA V", "Sleeping Dogs", "Max Payne 3"],
        "openworld": ["RDR2", "Watch Dogs", "Cyberpunk"],
        "adventure": ["Uncharted 4", "Tomb Raider", "Life is Strange"]
    }
    suggestions = genre_map.get(genre, [])
    msg = f"🎯 Try These:\n• " + '\n• '.join(suggestions) if suggestions else "🤔 Genre not found baby. Try: action, openworld, adventure"
    await update.message.reply_text(msg)

async def requestgame(update: Update, context: ContextTypes.DEFAULT_TYPE):
    game = ' '.join(context.args)
    if not game:
        await update.message.reply_text("📝 Use: /requestgame <game name>")
        return
    user = update.message.from_user.username or update.message.from_user.first_name
    game_requests[game] = user
    save_requests()
    await update.message.reply_text(f"✅ Request added for: {game} by {user}")

async def requestlist(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not game_requests:
        await update.message.reply_text("📭 No requests yet.")
        return
    msg = "📋 Game Requests:\n" + '\n'.join(f"• {g} – {u}" for g, u in game_requests.items())
    await update.message.reply_text(msg)

async def addcategory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❗Use: /addcategory <game> <category>")
        return
    game, category = context.args[0], context.args[1]
    categories.setdefault(category, []).append(game)
    save_categories()
    await update.message.reply_text(f"✅ {game} added to {category}")

async def listcategory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❗Use: /listcategory <category>")
        return
    category = context.args[0]
    if category in categories:
        msg = f"🎮 *{category.upper()} Games:*\n" + '\n'.join(f"• {g}" for g in categories[category])
        await update.message.reply_text(msg, parse_mode="Markdown")
    else:
        await update.message.reply_text("❌ Category not found.")

# =====================
# 🔄 Auto Handlers
# =====================
async def game_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if "🎮" in update.message.text and "Download Links" in update.message.text:
        title = update.message.text.splitlines()[0].replace("🎮", "").replace("– Full PC Game", "").strip()
        game_posts[title] = update.message.message_id
        save_games()

async def anti_fake_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if any(fake in update.message.text.lower() for fake in ["pubg 5gb", "hack game"]):
        await update.message.reply_text("⚠️ Fake Game Alert! Yeh post suspicious lagta hai.")
        await update.message.delete()

async def check_flood(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.message.from_user.id
    now = time.time()
    user_messages[uid] = [t for t in user_messages[uid] if now - t < FLOOD_TIME]
    user_messages[uid].append(now)

    if len(user_messages[uid]) > FLOOD_LIMIT:
        warns = user_warnings[uid] + 1
        user_warnings[uid] = warns
        save_data()
        if warns >= WARN_LIMIT:
            await update.message.reply_text("⛔ Auto-muted for spamming. You'll be unmuted in 10 mins.")

